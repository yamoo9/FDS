(function (global, angular) {
  'use strict';

  var fitbitApp = angular.module('fitbitApp');

  /** @controller ChallengeCtrl */
  fitbitApp.controller('ChallengeCtrl', ['$scope', function ($scope) {

  }]);

})(this, this.angular);

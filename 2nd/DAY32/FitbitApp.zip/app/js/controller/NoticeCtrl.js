(function (global, angular) {
  'use strict';

  var fitbitApp = angular.module('fitbitApp');

  /** @controller NoticeCtrl */
  fitbitApp.controller('NoticeCtrl', ['$scope', function ($scope) {

  }]);

})(this, this.angular);

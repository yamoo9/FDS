(function (global, angular) {
  'use strict';

  var fitbitApp = angular.module('fitbitApp');

  /** @controller MyPageCtrl */
  fitbitApp.controller('MyPageCtrl', ['$scope', function ($scope) {

  }]);

})(this, this.angular);

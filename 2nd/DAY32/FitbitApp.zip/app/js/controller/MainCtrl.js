(function (global, angular) {
  'use strict';

  var fitbitApp = angular.module('fitbitApp');

 /** @controller MainCtrl */
 fitbitApp.controller('MainCtrl', ['$scope', function ($scope) {

  }]);

})(this, this.angular);

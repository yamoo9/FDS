(function (global, angular) {
  'use strict';

  /** @type {Object} Angular App 모듈 정의 < 의존 모듈 [ngRoute, ngAnimate] */
  var fitbitApp = angular.module('fitbitApp', ['ngRoute', 'ngAnimate']);

  /** @config Route & Location Configuration 라우트&로케이션 설정 */
  fitbitApp.config(['$routeProvider', '$locationProvider', function( $routeProvider, $locationProvider ) {

    $routeProvider
      .when('/',{
        'templateUrl': '/views/main.html',
        'controller': 'MainCtrl'
      })
      .when('/friend',{
        'templateUrl': '/views/friend.html',
        'controller': 'FriendCtrl'
      })
      .when('/challenge',{
        'templateUrl': '/views/challenge.html',
        'controller': 'ChallengeCtrl'
      })
      .when('/notice',{
        'templateUrl': '/views/notice.html',
        'controller': 'NoticeCtrl'
      })
      .when('/mypage',{
        'templateUrl': '/views/mypage.html',
        'controller': 'MyPageCtrl'
      })
      .otherwise({
        'redirectTo': '/'
      });

    $locationProvider.html5Mode({
      'enabled': true,
      'requireBase': false
    });
  }]);

  fitbitApp.controller('IndexCtrl', ['$scope', '$location', function($scope, $location){
    $scope.activeClass = function (path) {
      var location_path = $location.path().substr(0, path.length);
      return location_path === path ? 'active' : '';
    };
  }]);

})(this, this.angular);

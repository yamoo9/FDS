// @private project {}
var project = {
  'source': './src/',
  'destination': './dist/'
};

// @exports config {}
var config = {
  'jade': {
    'src': project.source + '**/*.jade',
    'dest': project.destination,
    'options': {
      'pretty': true
    }
  },
  'sass': {
    'src': project.source + 'sass/**/*.{sass,scss}',
    'dest': project.destination + 'css',
    'sourcemaps': {
      'use': true,
      'location': '../maps'
    },
    'options': {
      // nested, compact, compressed
      'outputStyle': 'expanded'
    }
  },
};

// 외부 모듈 공개
module.exports = config;

